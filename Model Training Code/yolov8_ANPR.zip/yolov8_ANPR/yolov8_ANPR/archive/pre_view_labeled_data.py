import os
import cv2
import matplotlib.pyplot as plt

# Update this with your dataset directory
IMAGE_DIR = r'D:\archive\images\train'
LABEL_DIR = r'D:\archive\labels\train'

# Classes (update if you have more classes)
class_names = ['license_plate']

# Read a single image and its label
def load_and_draw(image_name):
    image_path = os.path.join(IMAGE_DIR, image_name)
    label_path = os.path.join(LABEL_DIR, os.path.splitext(image_name)[0] + '.txt')

    img = cv2.imread(image_path)
    if img is None:
        print(f"Error loading image: {image_path}")
        return

    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    h, w, _ = img.shape

    # Draw bounding boxes
    if os.path.exists(label_path):
        with open(label_path, 'r') as f:
            for line in f:
                parts = line.strip().split()
                class_id, x_center, y_center, box_width, box_height = map(float, parts)

                # Convert YOLO format to pixel values
                x1 = int((x_center - box_width / 2) * w)
                y1 = int((y_center - box_height / 2) * h)
                x2 = int((x_center + box_width / 2) * w)
                y2 = int((y_center + box_height / 2) * h)

                # Draw rectangle
                cv2.rectangle(img, (x1, y1), (x2, y2), (255, 0, 0), 2)
                label = class_names[int(class_id)]
                cv2.putText(img, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)
    else:
        print(f"No label file for image: {image_name}")

    # Show image
    plt.imshow(img)
    plt.title(image_name)
    plt.axis('off')
    plt.show()


# Loop through a few images
image_files = [f for f in os.listdir(IMAGE_DIR) if f.endswith(('.jpg', '.png'))]
print(len(image_files))
for img_file in image_files:  # Change the slice to see more
    load_and_draw(img_file)
